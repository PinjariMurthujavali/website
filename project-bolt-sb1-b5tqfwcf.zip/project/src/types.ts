export interface Project {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  price: number;
  demoUrl?: string;
  githubUrl?: string;
}

export interface Tutorial {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  category: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: string;
}