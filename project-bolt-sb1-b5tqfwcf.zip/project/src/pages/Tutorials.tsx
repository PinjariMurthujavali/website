import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Tutorial } from '../types';

export default function Tutorials() {
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    async function fetchTutorials() {
      const { data, error } = await supabase
        .from('tutorials')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        setTutorials(data);
      }
    }

    fetchTutorials();
  }, []);

  const filteredTutorials = selectedCategory === 'all'
    ? tutorials
    : tutorials.filter(tutorial => tutorial.category === selectedCategory);

  const categories = ['all', ...new Set(tutorials.map(tutorial => tutorial.category))];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Educational Tutorials</h1>

      {/* Category Filter */}
      <div className="mb-8">
        <div className="flex space-x-2 overflow-x-auto">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full ${
                selectedCategory === category
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Tutorials Grid */}
      <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {filteredTutorials.map((tutorial) => (
          <div key={tutorial.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={tutorial.thumbnailUrl}
              alt={tutorial.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <span className="inline-block px-3 py-1 text-sm font-semibold text-indigo-600 bg-indigo-100 rounded-full mb-2">
                {tutorial.category}
              </span>
              <h3 className="text-xl font-semibold text-gray-900">{tutorial.title}</h3>
              <p className="mt-2 text-gray-600">{tutorial.description}</p>
              <a
                href={tutorial.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Watch Tutorial
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}